package enigmaatletasartistas;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class EnigmaAtletasArtistas {
    private ArrayList pessoas = new ArrayList();
    
    public static void main(String[] args) {
        new EnigmaAtletasArtistas();
    }
    
    public EnigmaAtletasArtistas() {
        carregar(.....);
        mostrarPessoasCadastradas ();
    }
    
    public void mostrarPessoasCadastradas () {

    }    
    
   
}
